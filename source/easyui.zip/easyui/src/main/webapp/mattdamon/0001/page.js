$(document).ready(function() {
	page_init();
});

function page_init() {

	var columns_schema = [ {
		field : 'id',
		title : 'ID',
		align : 'center',
		sortable : true
	}, {
		field : 'product_id',
		title : '产品ID',
		align : 'center',
		sortable : true
	}, {
		field : 'directory',
		title : '所在目录',
		align : 'center'
	}, {
		field : 'file_name',
		title : '文件名称',
		align : 'center'
	}, {
		field : 'discription',
		title : '文件描述',
		align : 'center'
	}, {
		field : 'category_name',
		title : '文件类型',
		align : 'center'
	}, {
		field : 'real_url',
		title : 'URL',
		align : 'center'
	} ];

	var datagrid_data = [ {
		id : 1,
		product_id : '0001',
		directory : '/tpdata/upload/material/',
		file_name : 'clause.pdf',
		discription : '***保险条款',
		category_name : '保险条款',
		real_url : 'http://baoxian.cntaiping.com/material/0001/clause.pdf'
	}, {
		id : 2,
		product_id : '0002',
		directory : '/tpdata/upload/material/',
		file_name : 'FQA.html',
		discription : '***保险常见问题',
		category_name : '常见问题',
		real_url : 'http://baoxian.cntaiping.com/material/0002/FQA.html'
	} ];
	// 存在两种方式创建UI组件，1、css+div 2、javascript创建组件
	// 我们选择js方式
	var dg = $('#datagrid_node').datagrid({
		columns : [ columns_schema ],
		toolbar : [ {
			iconCls : 'icon-edit',
			id : 'edit',
			text : '编辑',
			handler : editHandler
		}, '-', {
			iconCls : 'icon-help',
			id : 'help',
			text : '帮助',
			handler : helpHandler
		} ],
		remoteSort : false, // 如果希望sortable生效，远程数据排序属性必须设为false
		fitColumns : true,// column宽度自适应，也可一在column_schema中定义width
		singleSelect : false, // 只允许单选行，默认是false
		pagination : true,// 分页控件比较复杂,分页可以先不做
		pagePosition : "bottom",
		pageNumber : 1,
		pageSize : 10,
		pageList : [ 10, 20, 30, 40, 50 ]
	});

	// 动态绑定数据
	$(dg).datagrid("loadData", datagrid_data);
}

function helpHandler() {
	alert("help");
}

function editHandler() {
	var rows = $('#datagrid_node').datagrid('getSelections');
	console.log(rows);
	alert("当前选择：" + rows.length + "行，打开debug控制台查看数据");
}